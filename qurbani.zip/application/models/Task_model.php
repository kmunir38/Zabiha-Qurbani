<?php defined('BASEPATH') OR exit('No direct script access allowed');

class task_model extends CI_Model {

    public function create($options)
    {
        $this->db->insert('share619_task', $options);
        return $this->db->insert_id();
    }

    public function get_all($limit = NULL, $offset = NULL)
    {
        $this->db->where('expiry_date >', date('Y-m-d'));
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('share619_task', $limit, $offset);
        return $query->result();
    }

    public function get_by($taskId)
    {
        $this->db->where('id', $taskId);
        $query = $this->db->get('share619_task');
        return $query->row();
    }

    public function update($id, $options)
    {
        $this->db->where('id', $id);
        $this->db->update('share619_task', $options);
        return $id;
    }

    public function destroy($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('share619_task');
        return $this->db->affected_rows();
    }
}