<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('task_model', 'task');
    }

    public function index()
    {
        $tasks = $this->task->get_all();
        if($tasks) {
            foreach($tasks as $task) {
                $data['tasks'][]  = [
                    'id' => $task->id,
                    'title' => $task->title,
                    'desc' => $task->description,
                    'cat' => $task->category,
                    'mask_url' => $task->mask_url,
                    'expiry_date' => $task->expiry_date,
                    'img' => ($task->media_img) ? base_url() . 'uploads/' . $task->media_img : null,
                    'points' => $task->points,
                ];
            }
            
            exit(json_encode($data));
        }
        exit(json_encode(['error' => "Sorry We doesn't have any records". date('Y-m-d')]));
    }
}