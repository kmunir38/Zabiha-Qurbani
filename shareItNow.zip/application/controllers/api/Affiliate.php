<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Affiliate extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('affiliate_model', 'aff');
    }

    public function index()
    {
        $email = $this->input->get('email');
        $password = $this->input->get('password');

        if($email & $password) {
            $where = [
                'email' => $email,
                'password' => $password
            ];


            $query = $this->aff->validate_credentials($where);

            if (!$query) {
                $where = [
                    'phone' => $this->input->get('email'),
                    'password' => $this->input->get('password')
                ];

                $query = $this->aff->validate_credentials($where);
            }

            if ($query) {
                $data = [
                    'id' => $query->id,
                    'points' => $query->points
                ];
            } else {
                $data['error'] = "Your Credential's Doesn't match our Records";
            }
        }
        else {
            $data['error'] = "Your Credential's Doesn't match our Records";
        }
        exit(json_encode($data));
    }
}