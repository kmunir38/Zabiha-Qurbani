<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Share extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('affiliate_model', 'aff');
        $this->load->model('task_model', 'task');
        $this->load->model('share_model', 'share');
    }

    public function index()
    {
        $aff_id = $this->input->get('affiliate_id');
        $task_id = $this->input->get('task_id');

        if($aff_id && $task_id) {

            $share_data = $this->share->get_by($aff_id, $task_id);

            if($share_data) {
                $options = [
                    'affiliate_id' => $aff_id,
                    'task_id' => $task_id,
                    'is_shared' => $share_data->is_shared + 1
                ];

                $share = $this->share->update($share_data->id, $options);
//                $share = $this->share->create($options);
            }
            else {
                $options = [
                    'affiliate_id' => $aff_id,
                    'task_id' => $task_id,
                    'is_shared' => 1
                ];
                $share = $this->share->create($options);
            }
            if($share) {
                $message = '1';
//                $task = $this->task->get_by($task_id);
//                $aff = $this->aff->get_by($aff_id);
//                $options = [
//                    'is_shared' => '1'
//                ];
//                $affiliate = $this->aff->update($aff_id,$options);
//                if($affiliate) {
//                    $message = '1';
//                }
//                else {
//                    $message = '0';
//                }
            }
            else {
                $message = '0';
            }
        }
        else {
            $message = '0';
        }

        echo json_encode(['status' => $message]);
        //exit($message);
    }
}