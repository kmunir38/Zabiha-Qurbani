<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('task_model', 'task');
        if (!isset($_SESSION['shareitnow_user_id'])) {
            redirect('/admin/','refresh');
        }
    }

    public function index()
    {
        $data['task'] = $this->task->get_all();
        $data['title'] = 'Task';
        $data['mainContent'] = 'admin/task/index';
        $this->load->view('admin/layout/master', $data);
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            $fileUpload = array();
            $hasFileUploaded = FALSE;

            $userFile = array(
                'upload_path' => './uploads/',
                'allowed_types' => 'jpg|jpeg|gif|png',
                'encrypt_name' => TRUE 
            );

            $this->upload->initialize($userFile);
            if (! $this->upload->do_upload('media_img')) {
                $data['error'] = $this->upload->display_errors();
            }
            else
            {
                $fileUpload = $this->upload->data();
                $hasFileUploaded = TRUE;

                if ($hasFileUploaded) 
                {
                    $title = $this->input->post('title');
                    $short_description = $this->input->post('short_description');
                    $description = $this->input->post('description');
                    $actual_url = $this->input->post('actual_url');
                    $category = $this->input->post('category');
                    $expiry_date = $this->input->post('expiry_date');
                    $media_img = $fileUpload['file_name'];
                    $points = $this->input->post('points');

                    if ($title & $actual_url) {
                        $options = [
                            'title' => $title,
                            'short_description' => $short_description,
                            'description' => $description,
                            'actual_url' => $actual_url,
                            'category' => $category,
                            'expiry_date' => $expiry_date,
                            'media_img' => $media_img,
                            'points' => $points
                        ];

                        $affected = $this->task->create($options);
                        if($affected)
                        {
                            $options = ['mask_url' => 'http://bookitnow.pk/shareitnow/task/'.$affected];
                            $this->task->update($affected, $options);

                            $data['message'] = "Succesfully Created";
                        }
                    }
                    else {
                        $data['error'] = "PLease Fill the rquired fields";
                    }
                }
            }
        }

        $data['title'] = 'Task';
        $data['mainContent'] = 'admin/task/add';
        $this->load->view('admin/layout/master', $data);
    }

    public function edit($id)
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            $fileUpload = array();
            $hasFileUploaded = FALSE;

            $userFile = array(
                'upload_path' => './uploads/',
                'allowed_types' => 'jpg|jpeg|gif|png',
                'encrypt_name' => TRUE 
            );

            $this->upload->initialize($userFile);

            if ($this->upload->do_upload('media_img')) 
            {
                $fileUpload = $this->upload->data();
                $hasFileUploaded = TRUE;
            }

            
            $title = $this->input->post('title');
            $short_description = $this->input->post('short_description');
            $description = $this->input->post('description');
            $actual_url = $this->input->post('actual_url');
            $category = $this->input->post('category');
            $expiry_date = $this->input->post('expiry_date');
            $media_img = ($hasFileUploaded) ? $fileUpload['file_name'] : $this->input->post('img_url');
            $points = $this->input->post('points');

            if ($title & $actual_url) {
                $options = [
                    'title' => $title,
                    'short_description' => $short_description,
                    'description' => $description,
                    'actual_url' => $actual_url,
                    'category' => $category,
                    'expiry_date' => $expiry_date,
                    'media_img' => $media_img,
                    'points' => $points
                ];

                $affected = $this->task->update($id, $options);
                if($affected)
                {
                    if ($hasFileUploaded) 
                        if (file_exists('./uploads/' . $this->input->post('img_url'))) 
                            unlink('./uploads/' . $this->input->post('img_url'));

                    $options = ['mask_url' => 'http://bookitnow.pk/shareitnow/task/'.$affected];
                    $this->task->update($affected, $options);

                    $data['message'] = "Succesfully Updated";
                }
            }
            else {
                $data['error'] = "PLease Fill the rquired fields";
            }
                
        }

        $data['task'] = $this->task->get_by($id);
        $data['title'] = 'Task';
        $data['mainContent'] = 'admin/task/edit';
        $this->load->view('admin/layout/master', $data);
    }

    public function delete($id)
    {

        $row = $this->task->get_by($id);
        $currentImg = $row->media_img;
        $affected = $this->task->destroy($id);
        if ($affected) 
        {
            unlink('./uploads/' . $currentImg);
            echo 1;
            //redirect('admin/brand','refresh');
        }

        $affected = $this->task->destroy($id);
        if($affected)
        {
            $data['message'] = "Deleted Successfully";
        }
        redirect(base_url().'admin/task');
    }
}