<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('affiliate_model', 'aff');
        $this->load->model('task_model', 'task');
        $this->load->model('share_model', 'share');
        if (!isset($_SESSION['shareitnow_user_id'])) {
            redirect('/admin/','refresh');
        }
    }

    public function affiliate()
    {
        $data['affiliate'] = $this->aff->get_all();
        $data['title'] = 'Affiliate';
        $data['mainContent'] = 'admin/report/view_affiliate';
        $this->load->view('admin/layout/master', $data);
    }

    public function task()
    {
        $data['task'] = $this->task->get_all();
        $data['title'] = 'Task';
        $data['mainContent'] = 'admin/report/view_task';
        $this->load->view('admin/layout/master', $data);
    }

    public function share()
    {
        $data['share'] = $this->share->get_views_report();
        $data['title'] = 'Shares';
        $data['mainContent'] = 'admin/report/view_share';
        $this->load->view('admin/layout/master', $data);
    }
}