<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('affiliate_model', 'aff');
        $this->load->model('task_model', 'task');
        $this->load->model('share_model', 'share');
    }

    public function index()
    {
        if (isset($_SESSION['user_id'])) {
            redirect('/admin/home/dashboard','refresh');
        }
        
        $this->load->view('admin/index');
    }

    public function validate()
    {
        $where = [
            'email' => $this->input->post('email'),
            'password' => $this->input->post('password')
        ];

        $query = $this->aff->validate_credentials($where);

        if ($query)
        {
            $shareitnow_data = [
                'shareitnow_fullname' => $query->name,
                'shareitnow_user_id' => $query->id,
                'shareitnow_is_logged_in' => TRUE
            ];

            $this->session->set_userdata($shareitnow_data);

            redirect('/admin/home/dashboard','refresh');
        }
        else
        {
            $data['error'] = "Sorry! Your Credentials didn't match our records";
            $this->load->view('admin/index', $data);
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('/admin','refresh');
    }

    public function dashboard()
    {
        if (!isset($_SESSION['shareitnow_user_id'])) {
            redirect('/admin/','refresh');
        }
        $data['title'] = 'Dashboard';
        $data['mainContent'] = 'admin/dashboard';
        $this->load->view('admin/layout/master', $data);
    }

    public function affiliateReport()
    {
        $aff_id = $this->input->get('aff_id');
        $affiliate = $this->share->get_count_by_affiliate($aff_id);
        
        $html = "<tr><td>".$affiliate->affiliate_id."</td><td>".$affiliate->shares."</td>
        <td>".$affiliate->views."</td></tr>";
        

        if(isset($html)) {
            print_r($html);
        }
         
    }

    public function taskReport()
    {
        $task_id = $this->input->get('task_id');
        $task = $this->share->get_count_by_task($task_id);
        
        $html = "<tr><td>".$task->task_id."</td><td>".$task->shares."</td>
        <td>".$task->views."</td></tr>";
        

        if(isset($html)) {
            print_r($html);
        }
         
    }

    public function salesAffiliateReport()
    {
        $aff_id = $this->input->get('aff_id');
        $affiliate = $this->share->get_sales_count_by_affiliate($aff_id);
        
        $html = "<tr><td>".$affiliate->affiliate_id."</td><td>".$affiliate->sales."</td></tr>";
        

        if(isset($html)) {
            print_r($html);
        }
         
    }

    public function salesTaskReport()
    {
        $task_id = $this->input->get('task_id');
        $task = $this->share->get_sales_count_by_task($task_id);
        
        $html = "<tr><td>".$task->task_id."</td><td>".$task->sales."</td></tr>";
        

        if(isset($html)) {
            print_r($html);
        }
         
    }
}
