<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Affiliate extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('affiliate_model', 'aff');
        if (!isset($_SESSION['shareitnow_user_id'])) {
            redirect('/admin/','refresh');
        }
    }

    public function index()
    {
        $data['affiliate'] = $this->aff->get_all();
        $data['title'] = 'Affiliate';
        $data['mainContent'] = 'admin/affiliate/index';
        $this->load->view('admin/layout/master', $data);
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            $name = $this->input->post('name');
            $phone = $this->input->post('phone');
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $check_email = $this->aff->checkEmail($email);

            if(!$check_email) {
                if ($name & $phone & $email & $password) {
                    $options = [
                        'name' => $name,
                        'phone' => $phone,
                        'email' => $email,
                        'password' => $password
                    ];

                    $affected = $this->aff->create($options);
                    if($affected)
                    {
                        $data['message'] = "Succesfully Created";
                    }
                }
                else {
                    $data['error'] = "PLease Fill the rquired fields";
                }
            }
            else {
                $data['error'] = "Email Allready Taken";
            }
        }

        $data['title'] = 'Affiliate';
        $data['mainContent'] = 'admin/affiliate/add';
        $this->load->view('admin/layout/master', $data);
    }

    public function edit($id) 
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            $name = $this->input->post('name');
            $phone = $this->input->post('phone');
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $check_email = $this->aff->checkEmail($email,$id);

            if(!$check_email) {
                if ($name & $phone & $email) {
                    if ($password) {
                        $options = [
                            'name' => $name,
                            'phone' => $phone,
                            'email' => $email,
                            'password' => $password
                        ];
                    } else {
                        $options = [
                            'name' => $name,
                            'phone' => $phone,
                            'email' => $email,
                        ];
                    }

                    $affected = $this->aff->update($id, $options);
                    if($affected)
                    {
                        $data['message'] = "Succesfully Updated";
                    }
                }
                else {
                    $data['error'] = "PLease Fill the rquired fields";
                }
            }
            else {
                $data['error'] = "Email Allready Taken";
            }
        }
        $data['affiliate'] = $this->aff->get_by($id);
        $data['title'] = 'Affiliate';
        $data['mainContent'] = 'admin/affiliate/edit';
        $this->load->view('admin/layout/master', $data);
    }

    public function delete($id)
    {
        $affected = $this->aff->destroy($id);
        if($affected)
        {
            $data['message'] = "Deleted Successfully";
        }
        redirect(base_url().'admin/affiliate');
    }

    public function checkEmail()
    {
        $email = $this->input->get('email');
        $id = $this->input->get('id');
        if($id) {
            echo $check_email = $this->aff->checkEmail($email, $id);
        } else {
            echo $check_email = $this->aff->checkEmail($email);
        }
    }
}