<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('affiliate_model', 'aff');
        $this->load->model('task_model', 'task');
        $this->load->model('share_model', 'share');
    }

    public function index($task_id)
    {
        $affiliate_id = $this->input->get('affiliate_id');

        if($affiliate_id) {
            $task = $this->task->get_by($task_id);
            $aff = $this->aff->get_by($affiliate_id);
            $share = $this->share->get_by($affiliate_id, $task_id);

            if(!preg_match('/bookitnow.pk/', $task->actual_url)){
                $options = [
                    'points' => $aff->points + $task->points
                ];
                $affiliate = $this->aff->update($affiliate_id, $options);
            }

            $options2 = [
                'is_viewed' => $share->is_viewed + 1
            ];

            $share = $this->share->update($share->id, $options2);
            

            if ($share) {
                if(preg_match('/bookitnow.pk/', $task->actual_url)){
                    redirect($task->actual_url . '?affiliate_id='. $affiliate_id . '&task_id=' . $task_id);
                }
                redirect($task->actual_url);
            }
        }
        else {
            $data['message'] = "Affiliate ID is Missing";
        }
    }
}