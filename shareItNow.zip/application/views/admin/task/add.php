<!-- main area -->
<div class="main-content">
    <div class="page-title">
        <div class="title">Task</div>
        <div class="sub-title">Add</div>
    </div>
    <div class="card bg-white">
        <div class="card-header">
            <?php if (isset($message)) : ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif ?>
            <?php if (isset($error)) : ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif ?>
        </div>
        <div class="card-block">
            <?php
            $attributes = array('name' => 'formAdd', 'id' => 'formAdd', 'class' => 'form-validation');
            echo form_open_multipart('', $attributes);
            ?>
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" class="form-control" placeholder="Title" required>
            </div>
            <div class="form-group">
                <label>Short Description</label>
                <textarea name="short_description" class="form-control"></textarea>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <div class="form-group">
                <label>Actual URL</label>
                <input type="url" name="actual_url" class="form-control" placeholder="Actual URL" required>
            </div>
            <div class="form-group">
                <label>Category</label>
                <input type="text" name="category" class="form-control" placeholder="Category" required>
            </div>
            <div class="form-group">
                <label>Points</label>
                <input type="number" name="points" class="form-control" placeholder="Points" required>
            </div>
            <div class="form-group">
                <label>Expiry Date</label>
                <input type="date" name="expiry_date" class="form-control" placeholder="Expiry Date">
            </div>
            <div class="form-group">
                <label>Expiry Date</label>
                <input name="media_img" id="media_img" type="file"  class="form-control">
            </div>
            <div class="form-group">
                <!--                    <a id="submit" onclick="submit()" class="btn btn-primary m-r">Submit</a>-->
                <button type="submit" class="btn btn-primary m-r">Submit</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
<!-- /main area -->
</div>
<!-- /content panel -->