<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables/media/css/jquery.dataTables.css">
<div class="page-title">
    <div class="title">Affiliate</div>
    <!-- <div class="sub-title">UI datatables</div> -->
</div>
<div class="card bg-white">
    <div class="card-header">
        Affiliate
    </div>
    <div class="card-block">
        <table class="table table-bordered table-striped datatable editable-datatable responsive align-middle bordered">
            <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Points</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($affiliate as $row) : ?>
            <tr>
                <td><?php echo $row->id ?></td>
                <td><?php echo $row->name ?></td>
                <td><?php echo $row->email ?></td>
                <td><?php echo $row->phone ?></td>
                <td><?php echo $row->points ?></td>
                <td><a href="/admin/affiliate/edit/<?php echo $row->id; ?>" style="font-size: 20px;" class="label label-info"> <i class="fa fa-edit"></i></a>
                    <a href="/admin/affiliate/delete/<?php echo $row->id; ?>" style="font-size: 20px;" class="label label-danger"> <i class="fa fa-trash-o"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- page scripts -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/media/js/jquery.dataTables.js"></script>
<!-- end page scripts -->
<!-- initialize page scripts -->
<script src="<?php echo base_url(); ?>assets/scripts/helpers/bootstrap-datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/scripts/tables/table-edit.js"></script>
<!-- end initialize page scripts -->