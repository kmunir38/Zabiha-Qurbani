<!-- main area -->
<div class="main-content">
    <div class="page-title">
        <div class="title">Affiliate</div>
        <div class="sub-title">Edit</div>
    </div>
    <div class="card bg-white">
        <div class="card-header">
            <?php if (isset($message)) : ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif ?>
            <?php if (isset($error)) : ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif ?>
        </div>
        <div class="card-block">
            <?php
            $attributes = array('name' => 'formAdd', 'id' => 'formAdd', 'class' => 'form-validation');
            echo form_open_multipart('', $attributes);
            ?>
            <input type="hidden" name="aff_id" id="aff_id" value="<?php echo $affiliate->id ?>">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo $affiliate->name ?>" required>
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="number" name="phone" min="11" class="form-control" placeholder="Phone" value="<?php echo $affiliate->phone ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="Email" value="<?php echo $affiliate->email ?>" required>
                <div id="error" style="display: none;" class="alert alert-danger"></div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password">
            </div>
            <div class="form-group">
                <!--                    <a id="submit" onclick="submit()" class="btn btn-primary m-r">Submit</a>-->
                <button type="submit" class="btn btn-primary m-r">Submit</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
<!-- /main area -->
</div>
<!-- /content panel -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
//    $("div").focusout(function(){
//        $(this).css("background-color", "#FFFFFF");
//    });


    $('#email').focusout(function () {
        var email = $(this).val();
        var id = $('#aff_id').val();
        $.get('/admin/affiliate/checkEmail', {email: email, id: id}, function (response) {
            if (response) {
                $('#error').css("display", "block");
                $('#error').text('Email Allready Taken');
            }
            else {
                $('#error').css("display", "none");
            }
        });
    });
</script>