<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables/media/css/jquery.dataTables.css">
<div class="main-content">
<div class="page-title">
    <div class="title">Task Reports</div>
</div>
<div class="card bg-white">
    <div class="card-header">
        Task
    </div>
    <div class="card-block">
        <table class="table table-bordered table-striped datatable editable-datatable responsive align-middle bordered">
            <thead>
            <tr>
                <th>Id</th>
                <th>Title</th>
                <th>Actual Url</th>
                <th>Mask Url</th>
                <th>Category</th>
                <th>Expiry Date</th>
                <th>Points</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($task as $row) : ?>
            <tr>
                <td><?php echo $row->id ?></td>
                <td><?php echo $row->title ?></td>
                <td><?php echo $row->actual_url ?></td>
                <td><?php echo $row->mask_url ?></td>
                <td><?php echo $row->category ?></td>
                <td><?php echo $row->expiry_date ?></td>
                <td><?php echo $row->points ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- page scripts -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/media/js/jquery.dataTables.js"></script>
<!-- end page scripts -->
<!-- initialize page scripts -->
<script src="<?php echo base_url(); ?>assets/scripts/helpers/bootstrap-datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/scripts/tables/table-edit.js"></script>
<!-- end initialize page scripts -->