<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables/media/css/jquery.dataTables.css">
<div class="main-content">
<div class="page-title">
    <div class="title">Share Reports</div>
</div>
<div class="card bg-white">
    <div class="card-header">
        Share
    </div>
    <div class="card-block">
        <table class="table table-bordered table-striped datatable editable-datatable responsive align-middle bordered">
            <thead>
            <tr>
                <th>Affiliate ID</th>
                <th>Name</th>
                <th>Task ID</th>
                <th>Task</th>
                <th>Shares</th>
                <th>Views</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($share as $row) : ?>
            <tr>
                <td><?php echo $row->aff_id ?></td>
                <td><?php echo $row->name ?></td>
                <td><?php echo $row->task_id ?></td>
                <td><?php echo $row->title ?></td>
                <td><?php echo $row->is_shared ?></td>
                <td><?php echo $row->is_viewed ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- page scripts -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/media/js/jquery.dataTables.js"></script>
<!-- end page scripts -->
<!-- initialize page scripts -->
<script src="<?php echo base_url(); ?>assets/scripts/helpers/bootstrap-datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/scripts/tables/table-edit.js"></script>
<!-- end initialize page scripts -->