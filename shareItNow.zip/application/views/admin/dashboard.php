        <!-- main area -->
        <div class="main-content">
            <div class="row col-md-12">
                <div class="col-md-6">
                    <div class="card bg-white m-b">
                        <div class="card-header">
                            Sales By Affiliate ID
                        </div>
                        <div class="card-block">
                            <div class="form-group">
                                <label>Input Affiliate ID</label>
                                <input type="number" name="sales_aff_id" id="sales_aff_id" class="form-control" placeholder="Affiliate ID" required>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped m-b-0">
                                    <thead>
                                    <tr>
                                        <th>Affiliate ID</th>
                                        <th>Sales</th>
                                    </tr>
                                    </thead>
                                    <tbody id="sales_aff_table">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card bg-white m-b">
                        <div class="card-header">
                            Sales By Task ID
                        </div>
                        <div class="card-block">
                            <div class="form-group">
                                <label>Input Task ID</label>
                                <input type="number" name="sales_task_id" id="sales_task_id" class="form-control" placeholder="Task ID" required>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped m-b-0">
                                    <thead>
                                    <tr>
                                        <th>Task ID</th>
                                        <th>Sales</th>
                                    </tr>
                                    </thead>
                                    <tbody id="sales_task_table">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row col-md-12">
                <div class="col-md-6">
                    <div class="card bg-white m-b">
                        <div class="card-header">
                            Views & Shares By Affiliate ID
                        </div>
                        <div class="card-block">
                            <div class="form-group">
                                <label>Input Affiliate ID</label>
                                <input type="number" name="aff_id" id="aff_id" class="form-control" placeholder="Affiliate ID" required>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped m-b-0">
                                    <thead>
                                    <tr>
                                        <th>Affiliate ID</th>
                                        <th>Shares</th>
                                        <th>Views</th>
                                    </tr>
                                    </thead>
                                    <tbody id="aff_table">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card bg-white m-b">
                        <div class="card-header">
                            Views & Shares By Task ID
                        </div>
                        <div class="card-block">
                            <div class="form-group">
                                <label>Input Task ID</label>
                                <input type="number" name="task_id" id="task_id" class="form-control" placeholder="Task ID" required>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped m-b-0">
                                    <thead>
                                    <tr>
                                        <th>Task ID</th>
                                        <th>Shares</th>
                                        <th>Views</th>
                                    </tr>
                                    </thead>
                                    <tbody id="task_table">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /main area -->
    </div>
    <!-- /content panel -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

        <script>
            $('#sales_aff_id').focusout(function(){
                var aff_id = $(this).val();
                $.get('<?php echo base_url(); ?>admin/home/salesAffiliateReport', {aff_id: aff_id}, function(data){
                    $('#sales_aff_table').html(data);
                });
            });

            $('#sales_task_id').focusout(function(){
                var task_id = $(this).val();
                $.get('<?php echo base_url(); ?>admin/home/salesTaskReport', {task_id: task_id}, function(data){
                    $('#sales_task_table').html(data);
                });
            });

            $('#aff_id').focusout(function(){
                var aff_id = $(this).val();
                $.get('<?php echo base_url(); ?>admin/home/affiliateReport', {aff_id: aff_id}, function(data){
                    $('#aff_table').html(data);
                });
            });

            $('#task_id').focusout(function(){
                var task_id = $(this).val();
                $.get('<?php echo base_url(); ?>admin/home/taskReport', {task_id: task_id}, function(data){
                    $('#task_table').html(data);
                });
            });
        </script>
