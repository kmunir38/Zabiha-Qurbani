<?php defined('BASEPATH') OR exit('No direct script access allowed');

class share_model extends CI_Model {

    public function create($options)
    {
        $this->db->insert('share619_share', $options);
        return $this->db->insert_id();
    }

    public function get_by($affId, $taskId)
    {
        $this->db->where('affiliate_id', $affId);
        $this->db->where('task_id', $taskId);
        $query = $this->db->get('share619_share');
        return $query->row();
    }

    public function update($shareId, $options)
    {
        $this->db->where('id', $shareId);
        $this->db->update('share619_share', $options);
        return $this->db->affected_rows();
    }

    public function get_views_report($limit = NULL, $offset = NULL)
    {
        $this->db->order_by('aff_id', 'DESC');
        $query = $this->db->get('share619_view_share', $limit, $offset);
        return $query->result();
    }

    public function get_by_affiliate($id)
    {
        $this->db->where('affiliate_id', $id);
        $query = $this->db->get('share619_share');
        return $query->row();
    }

    public function get_count_by_affiliate($id)
    {
        $this->db->select('affiliate_id, sum(is_shared) AS shares, sum(is_viewed) AS views');
        $this->db->where('affiliate_id', $id);
        $query = $this->db->get('share619_share');
        return $query->row();
    }

    
    public function get_count_by_task($id)
    {
        $this->db->select('task_id, sum(is_shared) AS shares, sum(is_viewed) AS views');
        $this->db->where('task_id', $id);
        $query = $this->db->get('share619_share');
        return $query->row();
    }

    public function get_sales_count_by_affiliate($id)
    {
        $this->db->select('affiliate_id, sum(sales) AS sales');
        $this->db->where('affiliate_id', $id);
        $query = $this->db->get('share619_share');
        return $query->row();
    }

    public function get_sales_count_by_task($id)
    {
        $this->db->select('task_id, sum(sales) AS sales');
        $this->db->where('task_id', $id);
        $query = $this->db->get('share619_share');
        return $query->row();
    }
}